import 'package:desktop_window/desktop_window.dart';
import 'package:flutter/material.dart';

import 'FileConsumer.dart';
import 'domain/component_loader.dart';
import 'domain/default_component.dart';

void main(){
  runApp(const App());
  //resize();
}

Future resize() async {
  Size size = await DesktopWindow.getWindowSize();
  double x = 300;
  double y = 100;
  await DesktopWindow.setFullScreen(false);
  await DesktopWindow.setWindowSize(Size(x,y));
  await DesktopWindow.setMinWindowSize(Size(x,y));
  await DesktopWindow.setMaxWindowSize(Size(x,y+900));
}

class App extends StatefulWidget {
  const App({Key? key}) : super(key: key);

  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {

  ComponentLoader loader = ComponentLoader(components: List.empty());
  FileConsumer fileConsumer = FileConsumer();

  void setFileConsumer() async {
    loader = await fileConsumer.processFile();
  }

  @override
  Widget build(BuildContext context) {
    void process() {
      setState(() {
        setFileConsumer();
      });
    }

    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        body: Column(
          children: [
            ElevatedButton(
                onPressed: () => process(),
                child: const Text("Open file")
            ),
            Expanded(
              child: ListView.builder(
                  itemCount: loader.components.length,
                  itemBuilder: (context, index) {
                    return createCard(loader.components[index]);
                  }
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget createCard(DefaultComponent defaultComponent) {
    return  ListTile(
      leading: const Icon(Icons.gradient),
      tileColor: Colors.cyan,
      title: Text(defaultComponent.name),
      subtitle: Row(
        children: [
          ElevatedButton(
              onPressed: () => {},
              child: Text("Do")
          ),
          ElevatedButton(
              onPressed: () => {},
              child: Text("Undo")
          ),
          Icon(Icons.circle, color: Colors.red,)
        ],
      ),
    );
  }
}